const express = require("express");
const authController = require("../controllers/auth");

const routers = express.Router();

routers.post('/register', authController.register);

module.exports = routers;