const express = require("express");

const routers = express.Router();

routers.get('/', (req,res) => {
    res.render('index');
});

routers.get('/register', (req,res) => {
    res.render('register');
});

module.exports = routers;